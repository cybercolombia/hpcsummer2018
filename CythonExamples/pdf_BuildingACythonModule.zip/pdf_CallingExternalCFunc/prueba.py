import numpy as np
import ejemplo1 

a=0
b=2.0
N=1000
print(ejemplo1.integrate_f(a,b,N))

