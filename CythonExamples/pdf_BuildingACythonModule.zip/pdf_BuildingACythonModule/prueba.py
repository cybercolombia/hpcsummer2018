import numpy as np
from hello import say_hello_to

say_hello_to("Veronica")
